//
//  ContentView.swift
//  Temperature Conversion
//
//  Created by Soros Wen on 2/6/20.
//  Copyright © 2020 Soros Wen. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    let inputTemperature = ["Celsius", "Fahrenheit", "Kelvin"]
    let outputTemperature = ["Celsius", "Fahrenheit", "Kelvin"]

    @State private var temperatureInputRow = 0
    @State private var temperatureOutputRow = 0

    var temperatureInputText: String{
        return inputTemperature[temperatureInputRow]
    }
    var temperatureOutputText: String{
        return outputTemperature[temperatureOutputRow]
    }

    @State private var InputValue = ""
    var OutputValue: Float{
        if temperatureInputText == "Celsius" &&  temperatureOutputText == "Celsius"{
            return Float(InputValue) ?? 0.0
        } else if temperatureInputText == "Celsius" &&  temperatureOutputText == "Fahrenheit"{
            return (Float(InputValue) ?? 0.0) * 9.0 / 5.0 + 32
        } else if temperatureInputText == "Celsius" &&  temperatureOutputText == "Kelvin"{
            return Float(InputValue) ?? 0.0 + 273.15
        } else if temperatureInputText == "Fahrenheit" &&  temperatureOutputText == "Celsius"{
            return (Float(InputValue) ?? 0.0) * 5.0 / 9.0 + 32
        } else if temperatureInputText == "Fahrenheit" &&  temperatureOutputText == "Fahrenheit"{
            return Float(InputValue) ?? 0.0
        } else if temperatureInputText == "Fahrenheit" &&  temperatureOutputText == "Kelvin"{
            return (Float(InputValue) ?? 0.0) * 5.0 / 9.0 + 273.15
        } else if temperatureInputText == "Kelvin" &&  temperatureOutputText == "Celsius" {
            return (Float(InputValue) ?? 0.0) - 273.15
        } else if temperatureInputText == "Kelvin" &&  temperatureOutputText == "Fahrenheit"{
            return ((Float(InputValue) ?? 0.0) - 273.15) * 9.0 / 5.0 + 32
        } else if temperatureInputText == "Kelvin" &&  temperatureOutputText == "Kelvin"{
            return Float(InputValue) ?? 0.0
        } else {
            return 0.0
        }
    }
    
    var body: some View{
        NavigationView{
            Form{
                Section{
                    HStack{
                        Text("\(temperatureInputText)")
                        TextField("\(temperatureInputText)", text: $InputValue)
                        Text("\(temperatureOutputText):  \(OutputValue, specifier: "%2.f") ")
                    }
                    HStack{
                        Picker("Input Unit", selection: $temperatureInputRow){
                            ForEach(0 ..< self.inputTemperature.count){
                                Text("\(self.inputTemperature[$0])")
                            }
                        }
                    }
                    HStack{
                        Picker("Output Unit", selection: $temperatureOutputRow){
                            ForEach(0 ..< self.outputTemperature.count){
                                Text("\(self.outputTemperature[$0])")
                            }
                        }
                    }
                }
            }.navigationBarTitle(Text("Temperature").font(.subheadline), displayMode: .large)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
